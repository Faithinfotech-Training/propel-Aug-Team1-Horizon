import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {Login} from 'src/app/shared/login';
import{AuthService} from '../shared/auth.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
 //declare variable for Formgroup
 loginForm:FormGroup;

 //declare variable for submit
 isSubmitted:boolean=false;

 //declare variable for error
 error:any='';

 //create a variable for Login
 loginUser:Login;
 uName:string;

  constructor(private formBuilder:FormBuilder, private authService:AuthService, private router:Router) { }

  ngOnInit(): void {
     //create Reactive Form
    //userName & password
    this.loginForm=this.formBuilder.group(
      //UserName
      //Password
      //FormControl Fields
      {
        userName: ['',[Validators.required]],
        password: ['',[Validators.required]]
      }
    );
  }
//get control for validation
get formControls(){
  return this.loginForm.controls;
}
//login verify method
loginCredentials(){
  this.isSubmitted=true;

  //form is valid
  if(this.loginForm.valid){
    //calling method from service
    this.authService.loginVerify(this.loginForm.value).subscribe(
      data=>{
        //success data
        console.log(data);
        this.uName=data.userName;

        localStorage.setItem('userName', data.userName);
        sessionStorage.setItem('userName', data.userName);
        localStorage.setItem('ACCESS_ROLE', data.userType.toString());
        //Form-level user-based authentication
          //checking userBased authorization
          if(data.userType==='admin'){
            //for memory storage
            this.router.navigateByUrl("/admin")
          }else if(data.userType===''){
            this.router.navigateByUrl("/receptionist")
          }
          },
          error=>{
            this.error="Invalid UserName and password";
          }
          )
        }
      }
    }
