import { Injectable } from '@angular/core';
import { Visit } from './visit';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VisitService {
//create an instance
formData: Visit = new Visit();
visits: Visit[];
constructor(private httpClient: HttpClient) {
  
}
//Get All visits 
getAllVisits() {
  this.httpClient.get(environment.apiUrl + "/visits").toPromise().then(
    response =>
      this.visits = response as Visit[]
  );

}
//Get a particular visits
getVisit(visitId: number): Observable<any>{
  return this.httpClient.get(environment.apiUrl + "/visits/"+{visitId});
}

//INSERT
insertVisit(visit : Visit): Observable<any>{
  return this.httpClient.post(environment.apiUrl + "/visits/",visit);
}
//UPDATE
updateVisit(visit : Visit): Observable<any>{
  return this.httpClient.put(environment.apiUrl + "/visits/",visit);
}
//DELETE
deleteVisit(visitId: number){
  return this.httpClient.delete(environment.apiUrl + "/visits/"+visitId);
}
}
