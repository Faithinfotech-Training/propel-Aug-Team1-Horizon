export class Employee {


    empId:number;
    firstName:string;
    lastName:string;
    age:number;
    gender:string;
    address:string;
    phoneNumber:string;
    l_Id:number;


    // private Integer empId;
	// private String firstName;
	// private String lastName;
	// private Integer age;
	// private String gender;
	// private String address;
	// private String phoneNumber;
	
	// private Integer logId;


}

