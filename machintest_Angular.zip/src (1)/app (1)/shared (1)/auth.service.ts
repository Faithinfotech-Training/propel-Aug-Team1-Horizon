import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { Login } from './login';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpClient:HttpClient,
    private router:Router) { }

        //Verify Login 
  public loginVerify(login: Login){
    console.log(login.userName);
    console.log(login.password);

    //calling web-service and passing username and password
    return this.httpClient.get<Login>(environment.apiUrl
    +"/logins/namepassword/"+ login.userName+ "&" + login.password);
      
}
//Logout
public logOut(){
  sessionStorage.removeItem("userName");
  localStorage.removeItem("userName");
  localStorage.removeItem("ACCESS_ROLE");
}
}

