export class Visit {
    visitId:number;
    custName:string;
    contactPerson:string;
    interestProduct:string;
    visitSubject:string;
    descrption:string;
    visitDate:Date = new Date();
    is_disabled:boolean;
    is_deleted:boolean;









    // private Integer visitId;
	// private String custName;
	// private String contactPerson;
	// private String contactNumber;
	// private String interestProduct;
	// private String visitSubject;
	// private String descrption;
	// private Date visitDate;
	// private Boolean is_disabled;
	// private Boolean is_deleted;
}
