import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  //create an instance
  formData: Employee = new Employee();
  employees: Employee[];
  constructor(private httpClient: HttpClient) {
    
  }
  //Get All employees 
  getAllEmployees() {
    this.httpClient.get(environment.apiUrl + "/employees").toPromise().then(
      response =>
        this.employees = response as Employee[]
    );

  }
  //Get a particular Employee
  getEmployee(empId: number): Observable<any>{
    return this.httpClient.get(environment.apiUrl + "/employees/"+{empId});
  }

  //INSERT
  insertEmployee(employee : Employee): Observable<any>{
    return this.httpClient.post(environment.apiUrl + "/employees/",employee);
  }
  //UPDATE
  updateEmployee(employee : Employee): Observable<any>{
    return this.httpClient.put(environment.apiUrl + "/employees/",employee);
  }
  //DELETE
  deleteEmployee(employeeId: number){
    return this.httpClient.delete(environment.apiUrl + "/employees/"+employeeId);
  }
}
