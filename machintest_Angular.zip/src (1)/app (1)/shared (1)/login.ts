export class Login {

    
    l_Id:number;
    userName:string;
    password:string;
    userType:string;



    // private Integer logId;
	// private String userName;
	// private String password;
	// private String userType;
    
}
