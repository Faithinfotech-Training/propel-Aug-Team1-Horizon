import { Visit } from './visit';

describe('Visit', () => {
  it('should create an instance', () => {
    expect(new Visit()).toBeTruthy();
  });
});
