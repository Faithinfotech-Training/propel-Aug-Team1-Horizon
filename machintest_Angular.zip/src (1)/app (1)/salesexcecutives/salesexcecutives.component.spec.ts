import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesexcecutivesComponent } from './salesexcecutives.component';

describe('SalesexcecutivesComponent', () => {
  let component: SalesexcecutivesComponent;
  let fixture: ComponentFixture<SalesexcecutivesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalesexcecutivesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesexcecutivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
