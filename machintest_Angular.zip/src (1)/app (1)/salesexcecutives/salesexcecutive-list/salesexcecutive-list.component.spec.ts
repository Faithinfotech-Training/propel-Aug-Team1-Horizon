import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesexcecutiveListComponent } from './salesexcecutive-list.component';

describe('SalesexcecutiveListComponent', () => {
  let component: SalesexcecutiveListComponent;
  let fixture: ComponentFixture<SalesexcecutiveListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalesexcecutiveListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesexcecutiveListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
