import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salesexcecutive-list',
  templateUrl: './salesexcecutive-list.component.html',
  styleUrls: ['./salesexcecutive-list.component.scss']
})
export class SalesexcecutiveListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
