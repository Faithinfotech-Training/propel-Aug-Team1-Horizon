import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salesexcecutives',
  templateUrl: './salesexcecutives.component.html',
  styleUrls: ['./salesexcecutives.component.scss']
})
export class SalesexcecutivesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
