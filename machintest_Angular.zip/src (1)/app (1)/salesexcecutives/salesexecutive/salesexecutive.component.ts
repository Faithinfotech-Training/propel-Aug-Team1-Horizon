import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salesexecutive',
  templateUrl: './salesexecutive.component.html',
  styleUrls: ['./salesexecutive.component.scss']
})
export class SalesexecutiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
