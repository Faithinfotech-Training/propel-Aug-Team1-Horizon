import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesexecutiveComponent } from './salesexecutive.component';

describe('SalesexecutiveComponent', () => {
  let component: SalesexecutiveComponent;
  let fixture: ComponentFixture<SalesexecutiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalesexecutiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesexecutiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
