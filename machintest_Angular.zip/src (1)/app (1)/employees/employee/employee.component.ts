import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EmployeeService } from 'src/app/shared/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {

  constructor(public employeeService: EmployeeService) { }

  ngOnInit(): void {
  }

  //onSubmit 
  onSubmit(form: NgForm) {
    //display
    console.log(form.value);

    let addId = this.employeeService.formData.empId;

    if (addId == 0 || addId == null) {
      //INSERT
      this.insertEmployee(form);
    } else {
      //UPDATE
      this.updateEmployee(form);

    }
  }

  //Insert Method
  insertEmployee(form?: NgForm) {
    console.log("Inserting a record");
    this.employeeService.insertEmployee(form.value).subscribe(
      result => {
        console.log(result);
        //it refreshes,when submit button is clicked
        window.location.reload();
        //clear all fields
      }

    );
  }
  //Update Method
  updateEmployee(form?: NgForm) {
    console.log("Uploading a record...");
    this.employeeService.updateEmployee(form.value).subscribe(
      //call back function
      (result) => {   // sucess
        console.log(result);
        window.location.reload();
        //clear all fields
      },
      (error) => {
        //error
      }
    );   
  }
}
