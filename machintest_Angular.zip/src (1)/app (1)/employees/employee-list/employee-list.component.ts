import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/shared/employee';
import { EmployeeService } from 'src/app/shared/employee.service'

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit {

  //constructor injection
  constructor(public employeeService : EmployeeService) { }

  ngOnInit(): void {  //life cycle hook
    //get all employees through service and stores in employees array
    this.employeeService.getAllEmployees();
  }

  //implement populate form
  //populate form by clicking the column fields
  populateForm(emp: Employee){
    console.log(emp);
    this.employeeService.formData=Object.assign({},emp);
    
  }
  //update employee
  updateEmployee(emp:Employee){
    this.employeeService.formData=Object.assign({},emp);
    this.employeeService.updateEmployee(emp);
    console.log(emp);

  }

  //delete employee
  deleteEmployee(empId: number){
    console.log(empId);
  }
}
